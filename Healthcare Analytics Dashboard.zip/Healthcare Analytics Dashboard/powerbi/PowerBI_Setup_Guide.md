# ⚡ Power BI — Healthcare Analytics Dashboard
## Full Setup Guide: MySQL Connection + DAX Measures + Visual Layout

---

## STEP 1 — CONNECT POWER BI TO MYSQL

### Prerequisites
- ✅ MySQL 8.0+ running (local or cloud)
- ✅ MySQL Connector/NET or ODBC driver installed
- ✅ Power BI Desktop (latest version)
- ✅ Database: `healthcare_analytics` created and populated

### Connection Steps
```
1. Open Power BI Desktop
2. Home → Get Data → More → Database → MySQL Database
3. Server:   localhost         (or your IP / cloud hostname)
   Database: healthcare_analytics
4. Authentication: Database → enter MySQL username & password
5. Navigator → select these views:
      ☑ vw_dashboard_main
      ☑ vw_kpi_summary
      ☑ vw_doctor_workload
      ☑ vw_monthly_trends
      ☑ vw_lab_analysis
      ☑ vw_cost_analysis
6. Click Load (or Transform Data for preview)
```

---

## STEP 2 — DATA MODEL RELATIONSHIPS

In Power BI **Model View**, create these relationships:

```
vw_dashboard_main[patient_id]    → patients[patient_id]   (Many-to-1)
vw_dashboard_main[doctor_name]   → vw_doctor_workload[doctor_name]  (Many-to-1)
vw_dashboard_main[visit_month]   → vw_monthly_trends[visit_month]  (Many-to-1)
vw_dashboard_main[department]    → vw_lab_analysis[department]      (Many-to-1)
vw_dashboard_main[department]    → vw_cost_analysis[department]     (Many-to-1)
```

> **Cross-filter direction**: Single (default) for all relationships.
> Set `month_sort` column as Sort By Column for `visit_month` in both trend tables.

---

## STEP 3 — DAX MEASURES
### (Create these in a new Measures table in Power BI)

```dax
-- ────────────────────────────────────────────────
-- CORE KPIs
-- ────────────────────────────────────────────────

Total Patients =
    DISTINCTCOUNT(vw_dashboard_main[patient_id])

Total Visits =
    COUNTROWS(vw_dashboard_main)

Avg Patient Age =
    AVERAGE(vw_dashboard_main[patient_age])

Total Revenue =
    SUM(vw_dashboard_main[visit_cost])

Avg Cost Per Visit =
    AVERAGE(vw_dashboard_main[visit_cost])


-- ────────────────────────────────────────────────
-- FOLLOW-UP RATE
-- ────────────────────────────────────────────────

Follow-Up Rate =
    DIVIDE(
        COUNTROWS(FILTER(vw_dashboard_main,
            vw_dashboard_main[followup_scheduled] = "Yes")),
        [Total Visits],
        0
    )

Follow-Up Rate % =
    FORMAT([Follow-Up Rate], "0.0%")


-- ────────────────────────────────────────────────
-- LAB RESULTS
-- ────────────────────────────────────────────────

Abnormal Labs =
    SUMX(vw_dashboard_main, vw_dashboard_main[is_abnormal])

Critical Labs =
    SUMX(vw_dashboard_main, vw_dashboard_main[is_critical])

Abnormal Lab Rate =
    DIVIDE([Abnormal Labs], [Total Visits], 0)

Abnormal Lab Rate % =
    FORMAT([Abnormal Lab Rate], "0.0%")


-- ────────────────────────────────────────────────
-- DOCTOR WORKLOAD
-- ────────────────────────────────────────────────

Doctor Workload Status =
    SWITCH(TRUE(),
        [Total Visits] > 90,  "🔴 HIGH",
        [Total Visits] > 70,  "🟡 MEDIUM",
        "🟢 OK"
    )

Avg Patients Per Doctor =
    DIVIDE([Total Visits],
        DISTINCTCOUNT(vw_dashboard_main[doctor_name]), 0)


-- ────────────────────────────────────────────────
-- MONTH-OVER-MONTH GROWTH
-- ────────────────────────────────────────────────

MoM Visit Growth =
    VAR CurrentVisits = [Total Visits]
    VAR PriorVisits =
        CALCULATE(
            [Total Visits],
            FILTER(
                ALL(vw_monthly_trends),
                vw_monthly_trends[month_sort] =
                    MAX(vw_monthly_trends[month_sort]) - 1
            )
        )
    RETURN
        DIVIDE(CurrentVisits - PriorVisits, PriorVisits, 0)

MoM Visit Growth % =
    FORMAT([MoM Visit Growth], "+0.0%;-0.0%;0.0%")


-- ────────────────────────────────────────────────
-- REVENUE ANALYSIS
-- ────────────────────────────────────────────────

Revenue Per Patient =
    DIVIDE([Total Revenue], [Total Patients], 0)

Revenue Share % =
    DIVIDE(
        [Total Revenue],
        CALCULATE([Total Revenue], ALL(vw_dashboard_main[department])),
        0
    )

Top Department Revenue =
    CALCULATE(
        MAX(vw_cost_analysis[total_revenue]),
        TOPN(1, vw_cost_analysis, vw_cost_analysis[total_revenue])
    )


-- ────────────────────────────────────────────────
-- EMERGENCY RATE
-- ────────────────────────────────────────────────

Emergency Rate =
    DIVIDE(
        SUMX(vw_dashboard_main, vw_dashboard_main[is_emergency]),
        [Total Visits],
        0
    )

Emergency Rate % =
    FORMAT([Emergency Rate], "0.0%")


-- ────────────────────────────────────────────────
-- DYNAMIC KPI TITLES (for card visuals)
-- ────────────────────────────────────────────────

KPI Title - Patients =
    "👥 " & FORMAT([Total Patients], "#,##0") & " Patients"

KPI Title - Revenue =
    "💊 $" & FORMAT([Total Revenue] / 1000, "#,##0.0") & "K Revenue"

KPI Title - Followup =
    "🔄 " & [Follow-Up Rate %] & " Follow-Up Rate"
```

---

## STEP 4 — DASHBOARD LAYOUT & VISUALS

### Page 1: Executive Summary
```
┌─────────┬─────────┬─────────┬─────────┬─────────┬─────────┐
│ CARD    │ CARD    │ CARD    │ CARD    │ CARD    │ CARD    │
│ Total   │ Total   │ Avg Age │ Follow  │ Avg     │ Total   │
│ Patients│ Visits  │         │ Up Rate │ Cost    │ Revenue │
├─────────┴─────────┴─────────┴─────────┴─────────┴─────────┤
│                                                             │
│  LINE CHART: Monthly Visits by Type (Emergency/Routine/    │
│             Follow-up/Specialist) — X=Month (sorted)       │
│                                                             │
├─────────────────────────────┬───────────────────────────────┤
│  DONUT CHART                │  BAR CHART                    │
│  Visit Type Distribution    │  Revenue by Department        │
│                             │                               │
└─────────────────────────────┴───────────────────────────────┘
```

### Page 2: Doctor Workload
```
┌───────────────────────────────────────────────────────────┐
│  TABLE: Doctor | Dept | Patients | Avg Cost | Abnormal %  │
│         | Followups | Revenue | Status (conditional color) │
├──────────────────────────┬────────────────────────────────┤
│  BAR CHART               │  GAUGE / KPI CARD              │
│  Patients per Doctor     │  Avg Patients per Doctor       │
└──────────────────────────┴────────────────────────────────┘
```

### Page 3: Lab Results
```
┌─────────────────────────────────────────────────────────┐
│  CARD: Abnormal Labs  │  CARD: Critical Labs             │
│  CARD: Abnormal Rate  │  CARD: Critical Rate             │
├─────────────────────────┬───────────────────────────────┤
│  CLUSTERED BAR          │  PIE CHART                    │
│  Abnormal Rate by Dept  │  Normal vs Abnormal vs        │
│                         │  Critical                     │
├─────────────────────────┴───────────────────────────────┤
│  TABLE: Dept | Normal | Abnormal | Critical | Rate       │
│         (Conditional formatting: red gradient on rate)   │
└─────────────────────────────────────────────────────────┘
```

### Page 4: Cost & Revenue
```
┌─────────────────────────────────────────────────────────┐
│  BAR CHART: Total Revenue by Department                  │
├────────────────────────┬────────────────────────────────┤
│  LINE CHART            │  TABLE                         │
│  Avg Cost Trend        │  Dept | Revenue | Avg Cost     │
│  by Month              │  | Share % | Min | Max         │
└────────────────────────┴────────────────────────────────┘
```

---

## STEP 5 — SLICERS (Add to all pages)

```
Slicer 1:  visit_month       → Dropdown or Tile style
Slicer 2:  department        → List style
Slicer 3:  doctor_name       → Dropdown
Slicer 4:  condition         → Dropdown
Slicer 5:  visit_type        → Tile style (4 buttons)
Slicer 6:  age_group         → Tile style (18-29 / 30-44 / 45-59 / 60+)
Slicer 7:  cost_tier         → Dropdown
```

> **Tip**: Use a separate **Slicer Panel** page and sync slicers
> across all pages via View → Sync Slicers.

---

## STEP 6 — CONDITIONAL FORMATTING

| Visual | Column | Rule |
|--------|--------|------|
| Doctor Table | workload_status | Text contains "HIGH" → Red background |
| Doctor Table | workload_status | Text contains "MEDIUM" → Orange background |
| Lab Table | abnormal_rate_pct | Color scale → White (0%) to Red (30%+) |
| Cost Table | revenue_share_pct | Data bars → Blue |
| Cost Table | avg_cost_per_visit | Top 20% → Yellow highlight |
| Cards | MoM Growth | Positive → Green, Negative → Red |

---

## STEP 7 — SCHEDULED REFRESH (Power BI Service)

```
1. Publish: Home → Publish → Select your Workspace
2. In Power BI Service (app.powerbi.com):
   → Datasets → Healthcare Analytics → Settings
   → Data Source Credentials → Edit → Enter MySQL credentials
   → Scheduled Refresh → ON → Daily (or hourly)
3. Set timezone and refresh times
4. Enable email alerts on refresh failure
```

---

## STEP 8 — RECOMMENDED THEME COLORS

```json
{
  "name": "Healthcare Dark",
  "dataColors": [
    "#2E75B6",
    "#1ABC9C",
    "#E74C3C",
    "#F39C12",
    "#8E44AD",
    "#27AE60"
  ],
  "background": "#FFFFFF",
  "foreground": "#1F3864",
  "tableAccent": "#2E75B6"
}
```
> **Apply theme**: View → Themes → Browse for themes → paste JSON

---

## QUICK REFERENCE — VIEWS TO VISUALS MAP

| Power BI Visual | MySQL View | Key Columns |
|-----------------|-----------|-------------|
| KPI Cards | `vw_kpi_summary` | total_patients, total_visits, avg_cost_per_visit, total_revenue, followup_rate_pct, abnormal_labs |
| Monthly Line Chart | `vw_monthly_trends` | visit_month (sorted by month_sort), total_visits, emergency, followup, routine, specialist |
| Doctor Table | `vw_doctor_workload` | doctor_name, total_patients, avg_cost, abnormal_rate_pct, workload_status |
| Lab Bar Chart | `vw_lab_analysis` | department, abnormal_count, critical_count, abnormal_rate_pct |
| Revenue Bar Chart | `vw_cost_analysis` | department, total_revenue, avg_cost_per_visit, revenue_share_pct |
| All Slicers | `vw_dashboard_main` | department, doctor_name, visit_month, condition, visit_type, age_group, cost_tier |
