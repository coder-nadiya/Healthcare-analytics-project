-- ================================================================
-- HEALTHCARE ANALYTICS DASHBOARD
-- MySQL Database Script — Power BI Ready
-- Compatible: MySQL 8.0+
-- ================================================================

-- ================================================================
-- SECTION 1: DATABASE SETUP
-- ================================================================

CREATE DATABASE IF NOT EXISTS healthcare_analytics
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE healthcare_analytics;

-- ----------------------------------------------------------------
-- Table: patients
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patients (
    patient_id      VARCHAR(10)     PRIMARY KEY,
    patient_age     INT             NOT NULL CHECK (patient_age BETWEEN 0 AND 120),
    gender          VARCHAR(10),
    join_date       DATE            DEFAULT (CURRENT_DATE)
);

-- ----------------------------------------------------------------
-- Table: doctors
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS doctors (
    doctor_id       INT             PRIMARY KEY AUTO_INCREMENT,
    doctor_name     VARCHAR(100)    NOT NULL,
    department      VARCHAR(50),
    specialty       VARCHAR(50)
);

-- ----------------------------------------------------------------
-- Table: visits (fact table)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS visits (
    visit_id            INT             PRIMARY KEY AUTO_INCREMENT,
    patient_id          VARCHAR(10)     NOT NULL,
    doctor_name         VARCHAR(100),
    department          VARCHAR(50),
    visit_month         VARCHAR(10),
    visit_date          DATE,
    `condition`         VARCHAR(50),
    visit_type          VARCHAR(20),
    visit_cost          DECIMAL(10,2)   CHECK (visit_cost >= 0),
    lab_result          VARCHAR(20),
    followup_scheduled  VARCHAR(5),
    CONSTRAINT fk_patient FOREIGN KEY (patient_id)
        REFERENCES patients(patient_id)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Indexes for Power BI query performance
CREATE INDEX idx_department    ON visits(department);
CREATE INDEX idx_doctor        ON visits(doctor_name);
CREATE INDEX idx_month         ON visits(visit_month);
CREATE INDEX idx_lab_result    ON visits(lab_result);
CREATE INDEX idx_visit_type    ON visits(visit_type);
CREATE INDEX idx_condition     ON visits(`condition`);


-- ================================================================
-- SECTION 2: SAMPLE DATA (500 rows via stored procedure)
-- ================================================================

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_InsertSampleData$$
CREATE PROCEDURE sp_InsertSampleData()
BEGIN
    DECLARE i INT DEFAULT 1;
    DECLARE v_dept      VARCHAR(50);
    DECLARE v_doc       VARCHAR(50);
    DECLARE v_cond      VARCHAR(50);
    DECLARE v_vtype     VARCHAR(20);
    DECLARE v_lab       VARCHAR(20);
    DECLARE v_followup  VARCHAR(5);
    DECLARE v_month     VARCHAR(10);
    DECLARE v_age       INT;
    DECLARE v_cost      DECIMAL(10,2);
    DECLARE v_pid       VARCHAR(10);
    DECLARE v_date      DATE;

    -- Seed patients
    SET i = 1;
    WHILE i <= 500 DO
        SET v_pid = CONCAT('P', LPAD(i, 4, '0'));
        SET v_age = FLOOR(18 + RAND() * 67);
        INSERT IGNORE INTO patients(patient_id, patient_age, gender)
        VALUES (
            v_pid,
            v_age,
            ELT(FLOOR(1 + RAND() * 2), 'Male', 'Female')
        );
        SET i = i + 1;
    END WHILE;

    -- Seed visits
    SET i = 1;
    WHILE i <= 500 DO
        SET v_pid    = CONCAT('P', LPAD(i, 4, '0'));

        SET v_dept   = ELT(FLOOR(1 + RAND() * 6),
                        'Cardiology','General','Pulmonology',
                        'Endocrinology','Neurology','Orthopedics');

        SET v_doc    = CASE v_dept
                        WHEN 'Cardiology'    THEN 'Dr. Chen'
                        WHEN 'General'       THEN 'Dr. Patel'
                        WHEN 'Pulmonology'   THEN 'Dr. Okafor'
                        WHEN 'Endocrinology' THEN 'Dr. Russo'
                        WHEN 'Neurology'     THEN 'Dr. Kim'
                        ELSE                      'Dr. Singh'
                       END;

        SET v_cond   = ELT(FLOOR(1 + RAND() * 6),
                        'Cardiac','Diabetes','Respiratory',
                        'Neurology','Orthopedics','Endocrine');

        SET v_vtype  = ELT(FLOOR(1 + RAND() * 4),
                        'Emergency','Follow-up','Routine','Specialist');

        SET v_lab    = ELT(FLOOR(1 + RAND() * 10),
                        'Abnormal','Abnormal','Critical',
                        'Normal','Normal','Normal',
                        'Normal','Normal','Normal','Normal');

        SET v_followup = IF(RAND() > 0.35, 'Yes', 'No');

        SET v_month  = ELT(FLOOR(1 + RAND() * 12),
                        'Jan','Feb','Mar','Apr','May','Jun',
                        'Jul','Aug','Sep','Oct','Nov','Dec');

        SET v_date   = DATE_ADD('2024-01-01',
                        INTERVAL FLOOR(RAND() * 365) DAY);

        SET v_cost   = ROUND(
                        CASE v_dept
                            WHEN 'Cardiology'    THEN 487
                            WHEN 'General'       THEN 178
                            WHEN 'Pulmonology'   THEN 134
                            WHEN 'Endocrinology' THEN 262
                            WHEN 'Neurology'     THEN 391
                            ELSE                      326
                        END * (0.7 + RAND() * 0.7), 2);

        INSERT INTO visits (
            patient_id, doctor_name, department,
            visit_month, visit_date, `condition`,
            visit_type, visit_cost, lab_result, followup_scheduled
        ) VALUES (
            v_pid, v_doc, v_dept,
            v_month, v_date, v_cond,
            v_vtype, v_cost, v_lab, v_followup
        );

        SET i = i + 1;
    END WHILE;
END$$

DELIMITER ;

-- Run to populate data
CALL sp_InsertSampleData();


-- ================================================================
-- SECTION 3: VIEWS FOR POWER BI (import these directly)
-- ================================================================

-- ----------------------------------------------------------------
-- VIEW 1: vw_dashboard_main  ← Connect this in Power BI
-- ----------------------------------------------------------------
CREATE OR REPLACE VIEW vw_dashboard_main AS
SELECT
    v.visit_id,
    v.patient_id,
    p.patient_age,
    p.gender,
    v.doctor_name,
    v.department,
    v.visit_month,
    v.visit_date,
    v.`condition`,
    v.visit_type,
    v.visit_cost,
    v.lab_result,
    v.followup_scheduled,
    -- Flags (use in Power BI DAX measures)
    CASE WHEN v.lab_result IN ('Abnormal','Critical') THEN 1 ELSE 0 END AS is_abnormal,
    CASE WHEN v.lab_result = 'Critical'               THEN 1 ELSE 0 END AS is_critical,
    CASE WHEN v.followup_scheduled = 'Yes'            THEN 1 ELSE 0 END AS is_followup,
    CASE WHEN v.visit_type = 'Emergency'              THEN 1 ELSE 0 END AS is_emergency,
    -- Age group segmentation
    CASE
        WHEN p.patient_age < 30 THEN '18-29'
        WHEN p.patient_age < 45 THEN '30-44'
        WHEN p.patient_age < 60 THEN '45-59'
        ELSE '60+'
    END AS age_group,
    -- Cost tier
    CASE
        WHEN v.visit_cost < 150 THEN '💚 Low (<$150)'
        WHEN v.visit_cost < 300 THEN '🟡 Medium ($150-300)'
        WHEN v.visit_cost < 450 THEN '🟠 High ($300-450)'
        ELSE '🔴 Premium (>$450)'
    END AS cost_tier,
    -- Month sort order for Power BI axis
    CASE v.visit_month
        WHEN 'Jan' THEN 1  WHEN 'Feb' THEN 2  WHEN 'Mar' THEN 3
        WHEN 'Apr' THEN 4  WHEN 'May' THEN 5  WHEN 'Jun' THEN 6
        WHEN 'Jul' THEN 7  WHEN 'Aug' THEN 8  WHEN 'Sep' THEN 9
        WHEN 'Oct' THEN 10 WHEN 'Nov' THEN 11 WHEN 'Dec' THEN 12
    END AS month_sort
FROM visits v
JOIN patients p ON v.patient_id = p.patient_id;


-- ----------------------------------------------------------------
-- VIEW 2: vw_kpi_summary  ← For KPI card visuals
-- ----------------------------------------------------------------
CREATE OR REPLACE VIEW vw_kpi_summary AS
SELECT
    COUNT(DISTINCT patient_id)                          AS total_patients,
    COUNT(*)                                             AS total_visits,
    ROUND(AVG(visit_cost), 2)                           AS avg_cost_per_visit,
    SUM(visit_cost)                                      AS total_revenue,
    ROUND(
        100.0 * SUM(CASE WHEN followup_scheduled='Yes' THEN 1 ELSE 0 END)
        / COUNT(*), 1)                                   AS followup_rate_pct,
    COUNT(CASE WHEN lab_result IN ('Abnormal','Critical') THEN 1 END) AS abnormal_labs,
    COUNT(CASE WHEN lab_result = 'Critical' THEN 1 END) AS critical_labs
FROM visits;


-- ----------------------------------------------------------------
-- VIEW 3: vw_doctor_workload  ← For doctor workload visual
-- ----------------------------------------------------------------
CREATE OR REPLACE VIEW vw_doctor_workload AS
SELECT
    doctor_name,
    department,
    COUNT(*)                                                    AS total_patients,
    ROUND(AVG(visit_cost), 2)                                   AS avg_cost,
    SUM(visit_cost)                                             AS total_revenue,
    COUNT(CASE WHEN lab_result IN ('Abnormal','Critical') THEN 1 END) AS abnormal_labs,
    ROUND(
        100.0 * COUNT(CASE WHEN lab_result IN ('Abnormal','Critical') THEN 1 END)
        / COUNT(*), 1)                                          AS abnormal_rate_pct,
    COUNT(CASE WHEN followup_scheduled = 'Yes' THEN 1 END)     AS followups,
    CASE
        WHEN COUNT(*) > 90  THEN 'HIGH 🔴'
        WHEN COUNT(*) > 70  THEN 'MEDIUM 🟡'
        ELSE 'OK 🟢'
    END AS workload_status
FROM visits
GROUP BY doctor_name, department
ORDER BY total_patients DESC;


-- ----------------------------------------------------------------
-- VIEW 4: vw_monthly_trends  ← For line/bar trend visuals
-- ----------------------------------------------------------------
CREATE OR REPLACE VIEW vw_monthly_trends AS
SELECT
    visit_month,
    CASE visit_month
        WHEN 'Jan' THEN 1  WHEN 'Feb' THEN 2  WHEN 'Mar' THEN 3
        WHEN 'Apr' THEN 4  WHEN 'May' THEN 5  WHEN 'Jun' THEN 6
        WHEN 'Jul' THEN 7  WHEN 'Aug' THEN 8  WHEN 'Sep' THEN 9
        WHEN 'Oct' THEN 10 WHEN 'Nov' THEN 11 WHEN 'Dec' THEN 12
    END                                                        AS month_sort,
    COUNT(*)                                                   AS total_visits,
    COUNT(CASE WHEN visit_type = 'Emergency'  THEN 1 END)      AS emergency,
    COUNT(CASE WHEN visit_type = 'Follow-up'  THEN 1 END)      AS followup,
    COUNT(CASE WHEN visit_type = 'Routine'    THEN 1 END)      AS routine,
    COUNT(CASE WHEN visit_type = 'Specialist' THEN 1 END)      AS specialist,
    ROUND(AVG(visit_cost), 2)                                  AS avg_cost,
    SUM(visit_cost)                                            AS total_revenue,
    COUNT(CASE WHEN lab_result IN ('Abnormal','Critical') THEN 1 END) AS abnormal_labs
FROM visits
GROUP BY visit_month
ORDER BY month_sort;


-- ----------------------------------------------------------------
-- VIEW 5: vw_lab_analysis  ← For lab result visuals
-- ----------------------------------------------------------------
CREATE OR REPLACE VIEW vw_lab_analysis AS
SELECT
    department,
    COUNT(CASE WHEN lab_result = 'Normal'   THEN 1 END) AS normal_count,
    COUNT(CASE WHEN lab_result = 'Abnormal' THEN 1 END) AS abnormal_count,
    COUNT(CASE WHEN lab_result = 'Critical' THEN 1 END) AS critical_count,
    COUNT(*)                                             AS total_tests,
    ROUND(
        100.0 * COUNT(CASE WHEN lab_result IN ('Abnormal','Critical') THEN 1 END)
        / COUNT(*), 1)                                   AS abnormal_rate_pct
FROM visits
GROUP BY department
ORDER BY abnormal_rate_pct DESC;


-- ----------------------------------------------------------------
-- VIEW 6: vw_cost_analysis  ← For revenue/cost visuals
-- ----------------------------------------------------------------
CREATE OR REPLACE VIEW vw_cost_analysis AS
SELECT
    department,
    COUNT(*)                    AS total_visits,
    SUM(visit_cost)             AS total_revenue,
    ROUND(AVG(visit_cost), 2)   AS avg_cost_per_visit,
    MIN(visit_cost)             AS min_cost,
    MAX(visit_cost)             AS max_cost,
    ROUND(
        100.0 * SUM(visit_cost) /
        (SELECT SUM(visit_cost) FROM visits), 1
    )                           AS revenue_share_pct
FROM visits
GROUP BY department
ORDER BY total_revenue DESC;


-- ================================================================
-- SECTION 4: KPI VERIFICATION QUERIES (run to test data)
-- ================================================================

-- Quick KPI check
SELECT
    (SELECT COUNT(DISTINCT patient_id) FROM visits)             AS total_patients,
    (SELECT COUNT(*)                   FROM visits)             AS total_visits,
    (SELECT ROUND(AVG(patient_age),1)  FROM patients)          AS avg_age,
    (SELECT ROUND(100*SUM(CASE WHEN followup_scheduled='Yes'
        THEN 1 ELSE 0 END)/COUNT(*),1) FROM visits)            AS followup_rate_pct,
    (SELECT ROUND(AVG(visit_cost),2)   FROM visits)            AS avg_cost_per_visit,
    (SELECT SUM(visit_cost)            FROM visits)            AS total_revenue,
    (SELECT COUNT(*) FROM visits
     WHERE lab_result IN ('Abnormal','Critical'))               AS abnormal_labs;


-- ================================================================
-- SECTION 5: STORED PROCEDURES FOR FILTERED REPORTING
-- ================================================================

DELIMITER $$

-- Get KPIs filtered by department and/or month
DROP PROCEDURE IF EXISTS sp_GetFilteredKPIs$$
CREATE PROCEDURE sp_GetFilteredKPIs(
    IN p_department VARCHAR(50),
    IN p_month      VARCHAR(10)
)
BEGIN
    SELECT
        department,
        visit_month,
        COUNT(*)                    AS total_visits,
        SUM(visit_cost)             AS total_revenue,
        ROUND(AVG(visit_cost), 2)   AS avg_cost,
        COUNT(CASE WHEN lab_result IN ('Abnormal','Critical') THEN 1 END) AS abnormal_labs,
        COUNT(CASE WHEN followup_scheduled = 'Yes' THEN 1 END) AS followups
    FROM visits
    WHERE
        (p_department IS NULL OR department = p_department)
        AND (p_month IS NULL OR visit_month = p_month)
    GROUP BY department, visit_month
    ORDER BY department, visit_month;
END$$

DELIMITER ;

-- Example calls:
-- CALL sp_GetFilteredKPIs('Cardiology', NULL);
-- CALL sp_GetFilteredKPIs(NULL, 'Jan');
-- CALL sp_GetFilteredKPIs(NULL, NULL);
